# recognize speech using IBM Speech to Text
APIKEY = "APIKEY"  
URL = "URL" 
